package p

import "go/ast"

func test() {
	var kind ast.ObjKind
	switch kind {
	}
}
