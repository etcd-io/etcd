// <<<<< extract,8,2,9,37,printB,pass
package main

import "fmt"

func main() {
	a := 3
	b := 4
	fmt.Println("The variable b is:", b)
	fmt.Println("The variable a is:", a, b)
}
