package main

import "fmt"

func main() {
	var2 := 2 // <<<<< var,6,10,6,10,var1,fail
	var1 := 1
	fmt.Printf("%d %d\n", var1, var2)
}
