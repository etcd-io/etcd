package main

import "fmt"

func main() {
  fmt.Println("Hello, Go") // <<<<< godoc,1,1,1,1,pass
}
