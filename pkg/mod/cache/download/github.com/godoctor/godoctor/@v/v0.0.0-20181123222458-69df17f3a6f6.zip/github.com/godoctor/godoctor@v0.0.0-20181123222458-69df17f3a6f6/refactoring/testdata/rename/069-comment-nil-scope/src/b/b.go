package b

// m
type I interface {
	// m
	m()
}

type T int

// m
func (T) m() {
}
