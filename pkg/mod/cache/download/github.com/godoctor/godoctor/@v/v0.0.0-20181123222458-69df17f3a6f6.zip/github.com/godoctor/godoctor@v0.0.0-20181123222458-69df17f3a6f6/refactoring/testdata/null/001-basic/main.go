package main

import "fmt"

func main() {
  fmt.Println("Hello, Go") // <<<<< null,1,1,1,1,false,pass
}
