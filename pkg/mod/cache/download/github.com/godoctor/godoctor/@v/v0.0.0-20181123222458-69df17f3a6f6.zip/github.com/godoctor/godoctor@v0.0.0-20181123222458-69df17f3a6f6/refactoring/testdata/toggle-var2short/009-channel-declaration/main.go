// <<<<< toggle,7,2,7,34,pass
package main

import "fmt"

func main() {
	var ch chan int = make(chan int)
	fmt.Println("Channel ch :",ch)
}
