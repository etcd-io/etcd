// <<<<< toggle,7,2,7,13,pass
package main

import "fmt"

func main() {
i,j := 2,7.9
fmt.Println("The value of variables i,j are :",i,j)
}
