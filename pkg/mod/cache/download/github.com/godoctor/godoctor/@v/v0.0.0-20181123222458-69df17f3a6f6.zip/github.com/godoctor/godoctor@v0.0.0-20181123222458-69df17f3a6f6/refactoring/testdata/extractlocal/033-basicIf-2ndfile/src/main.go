package main

import "fmt"
import "pkg"

func main() {
	fmt.Println(pkg.DoStuff())
}
