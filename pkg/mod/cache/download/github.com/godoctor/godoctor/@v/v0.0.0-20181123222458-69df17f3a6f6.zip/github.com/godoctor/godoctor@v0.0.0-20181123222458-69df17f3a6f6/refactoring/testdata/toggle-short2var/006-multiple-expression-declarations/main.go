// <<<<< toggle,7,2,7,13,pass
package main

import "fmt"

func main() {
i,j := 3.5+6,7+1
fmt.Println("The value of variables i,j are :",i,j)
}
