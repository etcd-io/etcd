//<<<<<extract,7,2,9,2,Foo,pass
package main

import "fmt"

func main() {
	for i := 0; i < 3; i++ {
		fmt.Println(i)
	}
}
