package a

// m
func M() {
}

// m
func m() { //<<<<<rename,8,6,8,6,xyz,pass
}
