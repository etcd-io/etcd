// <<<<< toggle,7,1,7,29,pass
package main

import "fmt"

func main() {
b:=[2]string{"hello","world"}
fmt.Println("The value of slice b is :",b)
}
