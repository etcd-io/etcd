// <<<<< toggle,7,2,7,26,pass
package main

import "fmt"

func main() {
	f := func()int {return 7}
	fmt.Println("Function f :",f)
}
