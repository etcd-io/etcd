// <<<<< toggle,7,1,7,15,pass
package main

import "fmt"

func main() {
var i,j = 2,7.9
fmt.Println("The value of variables i,j are :",i,j)
}
