package tmp2
var q int //q /q   q,qqq  q yes q. The name q appears four times in this quick comment for q // <<<<< rename,2,5,2,5,xx,pass
             
