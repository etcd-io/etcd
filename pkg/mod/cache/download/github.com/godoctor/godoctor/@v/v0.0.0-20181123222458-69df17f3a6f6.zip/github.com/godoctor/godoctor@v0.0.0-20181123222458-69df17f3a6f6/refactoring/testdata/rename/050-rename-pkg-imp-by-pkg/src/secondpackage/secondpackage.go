package secondpackage // <<<<< rename,1,10,1,10,Xyz,fail 
func Simplesquare(n int) int {             
	
return n*n

}
