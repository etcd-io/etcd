package main

func mail() { // <<<<<rename,3,6,3,10,main,pass
}
