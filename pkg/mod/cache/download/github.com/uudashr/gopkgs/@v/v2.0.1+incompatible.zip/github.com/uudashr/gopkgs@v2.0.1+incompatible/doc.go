// Package gopkgs is a utility to get list of golang packages.
package gopkgs
