package testdata

func Foo26(v interface{}) (_ string, i int, _ []byte, err error) {
	return "", 0, nil, nil
}
