package syntaxtest

// Plural all the types.
func Foo(s strings) errors {
	// Incorrect return type.
	return ""
}
