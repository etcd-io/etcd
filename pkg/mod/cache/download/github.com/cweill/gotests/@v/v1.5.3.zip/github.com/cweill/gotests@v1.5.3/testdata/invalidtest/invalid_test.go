package invalidtest

This is not Go code.