package testdata

func Foo10(m map[string]int32) map[string]*Bar { return nil }
