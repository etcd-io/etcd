package testdata

import (
	"go/ast"
	"go/types"
	"io"
)

func Foo24(r io.Reader, x ast.Expr, t types.Type) error { return nil }
