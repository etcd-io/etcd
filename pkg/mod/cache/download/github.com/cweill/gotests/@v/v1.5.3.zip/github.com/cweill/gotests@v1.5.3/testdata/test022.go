package testdata

import ht "html/template"

func Foo22(t *ht.Template) *ht.Template { return t }
