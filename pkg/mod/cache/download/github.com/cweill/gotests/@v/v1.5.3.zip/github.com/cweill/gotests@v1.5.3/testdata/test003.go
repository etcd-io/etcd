package testdata

func Foo3(s string) {}
