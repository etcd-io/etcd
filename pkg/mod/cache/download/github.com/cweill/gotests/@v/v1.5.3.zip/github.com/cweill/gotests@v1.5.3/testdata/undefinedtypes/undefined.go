package undefinedtypes

func (u *Undefined) Do(es Something) (*Unknown, error) {
	return nil, nil
}
