package pkg

type t1 struct{}
type T2 t1
