package pkg

//lint:file-ignore TEST1000 File-wide ignore

// the line directive should not affect the line ignores

//line random-file:1
func fn5() {}
